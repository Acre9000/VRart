using UnityEngine;

public class BakeryLightmapGroupSelector : MonoBehaviour
{
	public bool active = true;
    public Object lmgroupAsset;
    public bool instanceResolutionOverride = false;
    public int instanceResolution = 256;
}

