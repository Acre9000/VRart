# bakery-compiled
Compiled binaries of Bakery. If used with Unity, files should be placed in Assets/Editor/x64/Bakery

Not all existing binaries are present here - the repository is updated as each file gets patched.


